<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "hospital_db";

// Connect to database
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email    = $conn->real_escape_string($_POST['email']);
    $phone    = $conn->real_escape_string($_POST['phone']);
    $position = $conn->real_escape_string($_POST['position']);

    // Handle file upload
    if (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
        die("Resume upload failed.");
    }

    $resume_name = basename($_FILES['resume']['name']);
    $resume_tmp  = $_FILES['resume']['tmp_name'];

    $uploads_dir = __DIR__ . '/uploads';
    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0755, true);
    }

    $target_file = $uploads_dir . '/' . uniqid('resume_') . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $resume_name);

    if (!move_uploaded_file($resume_tmp, $target_file)) {
        die("Failed to move uploaded file.");
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO applicants (fullname, email, phone, position, resume) VALUES (?, ?, ?, ?, ?)");
    $resume_db = basename($target_file);
    $stmt->bind_param("sssss", $fullname, $email, $phone, $position, $resume_db);

    if ($stmt->execute()) {
        echo "<p>Application submitted successfully!</p>";
        echo "<p><a href='index.html'>Return home</a></p>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>