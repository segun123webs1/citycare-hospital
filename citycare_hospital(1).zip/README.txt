CityCare Hospital — Quick Setup

1. Place files in your PHP-enabled webroot (e.g., htdocs for XAMPP).
2. Create the database:
   - mysql -u root -p < database.sql
3. Ensure 'uploads' directory is writable (the script auto-creates it).
4. Visit index.html in your browser and test the form.

Security notes:
- This sample is minimal for learning. Add server-side validation, file type checks, and use prepared statements properly in production.
